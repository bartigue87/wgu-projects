//
//  degree.h
//  C867Project
//
//  Created by Brandon Artigue on 12/8/20.
//
#pragma once

#include <string>
enum DegreeProgram {UNDECIDED, SECURITY, NETWORK, SOFTWARE};
static const std::string degreeProgramStrings[] = {"UNDECIDED", "SECURITY", "NETWORK", "SOFTWARE"};
