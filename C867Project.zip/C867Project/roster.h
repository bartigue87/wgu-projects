//
//  roster.h
//  C867Project
//
//  Created by Brandon Artigue on 12/8/20.
//

#pragma once
#include "student.h"
class Roster
{
public:
    int lastIndex = -1;
    const static int numStudents = 5;
    Student* students[numStudents];
    
public:
    void parse(string row);
    void add(string stuID,
             string stuFirstName,
             string stuLastName,
             string stuEmail,
             int stuAge,
             double stuDay1,
             double stuDay2,
             double stuDay3,
             DegreeProgram dProgram);
    void remove(string stuID);
    void printAll();
    void printAverageDaysInCourse(string stuID);
    void printInvalidEmails();
    void printByDegreeProgram(DegreeProgram dProgram);
    ~Roster();
};
