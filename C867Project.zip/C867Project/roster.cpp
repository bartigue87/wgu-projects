//
//  roster.cpp
//  C867Project
//
//  Created by Brandon Artigue on 12/8/20.
//

#include "roster.h"


void Roster::parse(string studentData)
{
    DegreeProgram dp = UNDECIDED;
    if (studentData.back() == 'Y') dp = SECURITY;
    else if (studentData.back() == 'K') dp = NETWORK;
    else if (studentData.back() == 'E') dp = SOFTWARE;
    
    unsigned long rhs = studentData.find(",");
    string stuId = studentData.substr(0, rhs);
    
    unsigned long lhs = rhs + 1;
    rhs = studentData.find(",", lhs);
    string firstN = studentData.substr(lhs, rhs - lhs);
    
    lhs = rhs +1;
    rhs = studentData.find(",", lhs);
    string lastN = studentData.substr(lhs, rhs - lhs);
    
    lhs = rhs +1;
    rhs = studentData.find(",", lhs);
    string email = studentData.substr(lhs, rhs - lhs);
    
    lhs = rhs +1;
    rhs = studentData.find(",", lhs);
    int age = stoi(studentData.substr(lhs, rhs - lhs));
    
    lhs = rhs +1;
    rhs = studentData.find(",", lhs);
    double days1 = stod(studentData.substr(lhs, rhs -lhs));
    
    lhs = rhs +1;
    rhs = studentData.find(",", lhs);
    double days2 = stod(studentData.substr(lhs, rhs -lhs));
    
    lhs = rhs +1;
    rhs = studentData.find(",", lhs);
    double days3 = stod(studentData.substr(lhs, rhs -lhs));
    
    add(stuId, firstN, lastN, email, age, days1, days2, days3, dp);
    
    
}

void Roster::add(string studentID, string firstName, string lastName, string emailAddress, int age, double daysInCourse1, double daysInCourse2, double daysInCourse3, DegreeProgram degreeprogram)
{
    double dArr[3] = {daysInCourse1,daysInCourse2,daysInCourse3};
    students[++lastIndex] = new Student(studentID, firstName, lastName, emailAddress, age, dArr, degreeprogram);
}

void Roster::printAll()
{
    for (int i = 0; i <= Roster::lastIndex; i++)
    {
        cout << students[i]->getStudentId(); cout << '\t';
        cout << students[i]->getFirstName(); cout << '\t';
        cout << students[i]->getLastName(); cout << '\t';
        cout << students[i]->getEmail(); cout << '\t';
        cout << students[i]->getAge(); cout << '\t';
        cout << students[i]->getDaysInCourse()[0]; cout << '\t';
        cout << students[i]->getDaysInCourse()[1]; cout << '\t';
        cout << students[i]->getDaysInCourse()[2]; cout << '\t';
        cout << degreeProgramStrings[students[i]->getDegreeProgram()]; cout << std::endl;
    }
}

void Roster::printByDegreeProgram(DegreeProgram dProgram)
{
    for (int i = 0; i <= Roster::lastIndex; i++)
    {
        if(Roster::students[i]->getDegreeProgram() == dProgram) students[i]->print();
    }
    cout << std::endl;
}

//Note: A valid email should include an at sign ('@') and period ('.') and should not include a space (' ').
void Roster::printInvalidEmails()
{
    bool any = false;
    for (int i = 0; i <= Roster::lastIndex; i++)
    {
        string emailAddress = (students[i]->getEmail());
        if (emailAddress.find('@') == string::npos || emailAddress.find('.') == string::npos  || emailAddress.find(' ') != string::npos)
        {
            any = true;
            cout << students[i]->getEmail() << std::endl;
            
        }
    }
    if (!any) cout << "NONE" << std::endl;
}

void Roster::printAverageDaysInCourse(string stuID)
{
    for (int i = 0; i <= Roster::lastIndex; i++)
    {
        if (students[i]->getStudentId() == stuID)
        {
            cout << stuID << ": ";
            cout << (students[i]->getDaysInCourse()[0] + students[i]->getDaysInCourse()[1] + students[i]->getDaysInCourse()[2])/3.0 << std::endl;
        }
    }
}

void Roster::remove(string stuID)
{
    bool success = false;
    for (int i = 0; i <= Roster::lastIndex; i++)
    {
        if (students[i]->getStudentId() == stuID)
        {
            success = true;
            if (i < numStudents - 1)
            {
                Student* temp = students[i];
                students[i] = students[numStudents - 1];
                students[numStudents - 1] = temp;
            }
            Roster::lastIndex--;
        }
        
    }
    if (success)
    {
        cout << stuID << " removed from the roster." << std::endl;
        this->printAll();
    }
    else cout << stuID << " was not found." << std::endl;
}

Roster::~Roster()
{
    for (int i = 0; i < numStudents; i++)
    {
        delete students[i];
        students[i] = nullptr;
    }
}
