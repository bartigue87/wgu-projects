//
//  student.h
//  C867Project
//
//  Created by Brandon Artigue on 12/8/20.
//
#pragma once

#include <iostream>
#include "degree.h"

using std::string;
using std::cout;

class Student
{
public:
    const static int arraySize = 3;
private:
    string studentId;
    string firstName;
    string lastName;
    string email;
    int age;
    double daysInCourse[arraySize];
    DegreeProgram degreeProgram;
public:
    Student();
    Student(string studentId, string firstName, string lastName, string email, int age, double daysInCourse[], DegreeProgram degreeProgram);
    ~Student();

    string getStudentId();
    string getFirstName();
    string getLastName();
    string getEmail();
    int getAge();
    double* getDaysInCourse();
    DegreeProgram getDegreeProgram();
    

    void setStudentId(string studentId);
    void setFirstName(string firstName);
    void setLastName(string lastName);
    void setEmail(string email);
    void setAge(int age);
    void setDaysInCourse(double daysInCourse[]);
    void setDegreeProgram(DegreeProgram degreeProgram);
    
    void print();
    
};
